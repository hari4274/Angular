<!-- Postgres SQL connection  user : php_user Password: php_user -->
CREATE SEQUENCE users_seq start 1 increment 1;
ALTER SEQUENCE users_seq OWNER TO php_user;
CREATE TABLE users
(
  id integer NOT NULL DEFAULT nextval('users_id_seq'::regclass),
  name character varying NOT NULL,
  username character varying NOT NULL,
  password character varying NOT NULL,
  email character varying(150) NOT NULL
);
ALTER TABLE users OWNER TO php_user;


CREATE SEQUENCE feed_seq start 1 increment 1;
ALTER SEQUENCE feed_seq OWNER TO php_user;
CREATE TABLE feed(
feed_id integer NOT NULL DEFAULT nextval('feed_seq'::regclass),
feed character varying,
user_id_fk integer,
created integer
);
ALTER TABLE feed OWNER TO php_user;

CREATE SEQUENCE emailusers_seq start 1 increment 1;
ALTER SEQUENCE emailusers_seq OWNER TO php_user;
CREATE TABLE emailUsers (
  user_id integer not null default nextval('emailusers_seq'::regclass),
  email character varying DEFAULT NULL,
  name character varying DEFAULT NULL
);
ALTER TABLE emailusers OWNER TO php_user;


CREATE SEQUENCE imagesdata_seq start 1 increment 1;
ALTER SEQUENCE imagesdata_seq OWNER TO php_user;
CREATE TABLE imagesData (
  img_id integer not null default nextval('imagesdata_seq'::regclass),
  b64 character varying DEFAULT NULL,
  user_id_fk integer DEFAULT NULL
);
ALTER TABLE imagesdata OWNER TO php_user;