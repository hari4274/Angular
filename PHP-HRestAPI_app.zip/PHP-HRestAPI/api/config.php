<?php
//ob_start("ob_gzhandler");
error_reporting(0);
session_start();
/* DATABASE CONFIGURATION */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'php_user');
define('DB_PASSWORD', 'php_user');
define('DB_DATABASE', 'php_db');
// define("BASE_URL", "http://localhost/php_tests/PHP-HRestAPI/api/");
define("BASE_APIURL", $_SERVER['REQUEST_SCHEME']."://".$_SERVER['SERVER_ADDR'].":".$_SERVER['SERVER_PORT']."/php_tests/PHP-HRestAPI/api/");
define("SITE_KEY", 'hionic');


function getDB() 
{
	$dbhost=DB_SERVER;
	$dbuser=DB_USERNAME;
	$dbpass=DB_PASSWORD;
	$dbname=DB_DATABASE;
	// $dbConnection = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);	
	$dbConnection = new PDO("pgsql:host=$dbhost;port=5432;dbname=$dbname", $dbuser, $dbpass);	
	// pgsql:host=$dbhost;port=5432;dbname=$dbname;$dbuser, $dbpass
	$dbConnection->exec("set names utf8");
	$dbConnection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	return $dbConnection;
}
/* DATABASE CONFIGURATION END */

/* API key encryption */
function apiToken($session_uid)
{
$key=md5(SITE_KEY.$session_uid);
return hash('sha256', $key);
}

// URL Str to JSON obj
// "name=aa&pwd=123" to $jsonobj->name
function urldata2json() {

	// $data = explode("&", file_get_contents('php://input')); //not supports for get method so moveto nxt line code
	
	$postdata = file_get_contents("php://input");
    
	// $data = $_REQUEST ? $_REQUEST : $_GET;
	// echo gettype($data);
	// echo "<br/>".count($data);
	// print_r(json_encode($data)->key);
	// return (count($data) != 0) ? json_decode(json_encode($postdata)) : false;
	return (isset($postdata)) ? json_decode($postdata) : false;

	// if (count($data) != 0) {
	// 	$json = json_encode($data);
	// 	$json = json_decode($json, false);
	// 	return $json;
	// }
	// else {
	// 	return false;
	// }
}


?>